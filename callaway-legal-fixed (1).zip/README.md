# Callaway Legal Website

Upload every file in this folder directly to the root of the GitHub repository.

Required files:
- index.html
- privacy.html
- style.css
- script.js
- attorney.png
- logo.svg
- favicon.svg

GitHub Pages should use:
- Branch: main
- Folder: / (root)
